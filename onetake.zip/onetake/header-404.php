<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  
  
  
  <link rel="shortcut icon" href="http://www.winter.com/wp-content/uploads/2015/10/favicon.ico" type="image/x-icon">
<link rel="icon" href="http://www.winter.com/wp-content/uploads/2015/10/favicon.ico" type="image/x-icon">
  

  
  
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<?php wp_head();?>
</head>
<body <?php body_class(); ?>>
	 
    
	