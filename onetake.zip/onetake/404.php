<head><meta http-equiv="refresh" content="4; url=http://www.winter.com/" /></head>

<?php
/**
* The sigle template file.
*
*/
 get_header("404")

?>
<div id="post-404-not-found" <?php post_class("clear"); ?>

<div id="main" class="clearfix container" style="background: url(http://www.winter.com/wp-content/uploads/2015/10/invest_bg.png) no-repeat; background-size: 100% 100%; padding-top: 40px; padding-bottom: 80px; line-height: 1.75em">
<div class="row">

<div class="col-md-12">
<section class="blog-main text-center" role="main">
                            <article>
                                <div class="entry-main no-img">
                                    <div class="entry-content" style="margin-top:150px; height: 2000px">
                                      
                                      
                                      <h1>Page Not Found</h1>
                                      <br /><br /><br />
                                      <p>Sorry, but the page you requested has not been found. <br />Please <a href="http://www.winter.com/"><span style="font-family:Rajdhani-SemiBold; color:#6b9bc8">Click Here</span></a> if you are not automatically redirected to our homepage. </p>
                                      
                                      
                                    
                                    </div>
                                </div>
                            </article>
                        </section>
</div>
<!--<div class="col-md-3">
<aside class="sidebar">
<div class="widget-area">
 <?php get_sidebar( '404' ); ?>
</div>
</aside>
</div>-->

</div>
</div>
</div>
<?php get_footer(); ?>