<?php
/**
* The map template file.
*
*/
?>
<style type="text/css">
#map-canvas {
    width: 100%;
    height: 680px;
}
</style>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&signed_in=true"></script>
<script type="text/javascript">
google.maps.event.addDomListener(window, 'load', gmaps_results_initialize);
/**
 * Renders a Google Maps centered on NYC. This is done by using
 * the Latitude and Longitude for the city.
 *
 *
 * @since    1.0.0
 */
  
var map;
var bounds;
  
function gmaps_results_initialize() {
    var image = '/wp-content/uploads/2015/10/PastedGraphic-11.png';
    var _111fifth = {
        lat: 40.759460967067405,
        lng: -73.97615740209962
    };

    		bounds = new google.maps.LatLngBounds();
    		map = new google.maps.Map(document.getElementById('map-canvas'), {
        zoom: 13,
        center: new google.maps.LatLng(40.755430034401776, -73.97495577246094),
        scrollwheel: false,

    });

    // Multiple Markers
    var markers = [
        ['800 Fifth Avenue', 40.765644, -73.971621, '800fifth/'],
        ['135 West 74th Street', 40.779566, -73.979223, '135east74th/'],
        ['130 East 75th Street', 40.772421, -73.961164, '130east75th/'],
        ['210 Central Park South', 40.766993, -73.980011, '210cps/'],
        ['340 East 24th Street', 40.737660, -73.978825, '340east24th/'],
        ['165 West 66th Street', 40.774876, -73.984073, '165west66th/'],
        ['261-267 West 25th Street', 40.746424, -73.996702, '261west25th/'],
        ['175 East 13th Street', 40.732650, -73.987835, '175east13th/'],
        ['One Vandam street', 40.726283, -74.003814, 'onevandam/'],
        ['155 East 73rd Street', 40.771079, -73.961223, '155east73rd/'],
        ['419 East 57th Street', 40.758205, -73.961938, '419east57th/'],
        ['520 East 76th Street', 40.768788, -73.950899, '520east76th/'],
        ['120 East 36th Street', 40.747733, -73.979449, '120east36th/'],
        ['340 Flatbush Avenue', 40.676108, -73.972002, '340flatbush/'],
        ['404-408 West 14th Street', 40.741163, -74.005879, '404west14th/'],
        ['111-115 Fifth Avenue', 40.738864, -73.991155, '111fifth/'],
        ['423 West 55th Street', 40.767426, -73.987980, '423west55th/'],
        ['26 West 17th Street', 40.738426, -73.993818, '26west17th-2/'],
        ['18 East 16th Street', 40.736626, -73.991872, '18east16th-2/'],
        ['3 East 28th Street', 40.744549, -73.986646, '3east28th/'],
        ['599 Eleventh Avenue', 40.762752, -73.997410, '599eleventh/'],
        ['16 West 46th Street', 40.756272, -73.980256, '16west46th/'],
        ['57 East 11th Street', 40.733157, -73.992368, '57east11th/'],
        ['730 Fifth Avenue', 40.762850, -73.974596, 'tcb/'],
        ['719-723 8th Avenue', 40.666421, -73.978466, '719eighth/'],
        ['21 East 26th Street', 40.743126, -73.986970, 'whitman/'],
    ];

    // Display multiple markers on a map
    var infoWindow = new google.maps.InfoWindow(),
        marker, i;

    // Loop through our array of markers & place each one on the map
    for (i = 0; i < markers.length; i++) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        bounds.extend(position);
        marker = new google.maps.Marker({
            position: position,
            map: map,
            title: markers[i][0],
            url: markers[i][3],
            icon: image
        });

        marker.addListener('mouseover', function (marker, i) {
          jQuery('.leftNav a[href$="' + this.url + '"]').first().addClass('active');
          console.log(jQuery('.leftNav a[href$="' + this.url + '"]').first());
        });

        marker.addListener('mouseout', function (marker, i) {
          jQuery('.leftNav a[href$="' + this.url + '"]').first().removeClass('active');
          console.log(jQuery('.leftNav a[href$="' + this.url + '"]').first());
        });

        // Allow each marker to have an info window
        marker.addListener('click', function (marker, i) {
          jQuery.fancybox({ type: 'iframe', href: this.url, overlay: false, width: '100%', height: '100%' });
          return false;
        });

        // Automatically center the map fitting all markers on the screen
        //map.fitBounds(bounds);

    }

    // // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
    // var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
    //     this.setZoom(12);
    //     google.maps.event.removeListener(boundsListener);
    // });
}
  
  function resetMap() {

    map.setOptions({
        center: new google.maps.LatLng(40.755430034401776, -73.97495577246094),
        zoom: 13
    });

}

  
  jQuery("#menu-item-837").on("click", function(){
    resetMap();
  });  
  
  jQuery("#menu-item-5").on("click", function(){
    resetMap();
  });
  jQuery("#menu-item-95").on("click", function(){
    resetMap();
  });
  jQuery("#menu-item-24").on("click", function(){
    resetMap();
  });
  jQuery("#menu-item-7").on("click", function(){
    resetMap();
  });
  jQuery("#menu-item-62").on("click", function(){
    resetMap();
  });  
</script>