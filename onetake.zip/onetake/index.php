<?php
/**
 * The main file.
 *
 * @since onetake 1.0.0
 */

get_header();

get_template_part("content","blog-list");

get_footer();
 