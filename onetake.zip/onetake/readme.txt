Onetake Theme
================

The theme itself is nothing but 100% GPL v2 or later.


Icon
 * License: The icons are free for personal use and also free for commercial use.
   All icons are under GPL v2+ have been created by our team.
 * Copyright: hoothemes.com, http://www.hoothemes.com

--------------------------------------------------------------------------------------------

Font 
==Awesome 4.2.0
 * License: License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 * Copyright: by @davegandy - http://fontawesome.io - @fontawesome
--------------------------------------------------------------------------------------------

Images
 * License: Banner images are from Unsplash with "do whatever you want" license. 
 * Copyright: http://unsplash.com/

--------------------------------------------------------------------------------------------

Administration Panel 
 * License: For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. 
 * Copyright: Devin Price, http://wptheming.com/options-framework-plugin/ 

--------------------------------------------------------------------------------------------

JS files

bootstrap.min.js
 * Licensed under http://www.apache.org/licenses/LICENSE-2.0
 * Copyright 2013 Twitter, Inc.

jquery.nav.js
 * License: Dual licensed under the MIT and GPL licenses.
 * Copyright (c) 2010 Trevor Davis (http://trevordavis.net)

html5.js
 * License: MIT/GPL2 Licensed
 * Copyright: @afarkas @jdalton @jon_neal @rem

jquery.tubular.1.0.js
 * License: licensed under the MIT License
 * Copyright: by Sean McCambridge  http://www.seanmccambridge.com/tubular

modernizr.custom.js
 * License: MIT & BSD

respond.min.js
 * License: Licensed under MIT
 * Copyright 2014 Scott Jehl
 
 
 queryloader2.js
 jqueryloader2.min.js
 QueryLoader.js
 ImageLoaded.js
 
 * QueryLoader2 - A simple script to create a preloader for images
 *
 * For instructions read the original post:
 * http://www.gayadesign.com/diy/queryloader2-preload-your-images-with-ease/
 *
 * Copyright (c) 2011 - Gaya Kessler
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 
 
 jquery.nicescroll.js
* copyright 2011-12-13 InuYaksa*2013
*licensed under the MIT
--------------------------------------------------------------------------------------------

	For any help you can mail me at support[at]hoosoft.com
