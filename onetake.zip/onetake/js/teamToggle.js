jQuery(document).ready(function ($) {
    var activeTab = $('.slidetabs .active a').attr('href');
    // Show/Hide Tabs
    $('.slidetabs ' + activeTab).show().siblings().hide();

    $(".toggleTeam").click(function() {
        $("#hiddenTeam").toggle();
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
      console.log('fooy');
        var sliderEl = $($(e.target).attr('href')).find('.royalSlider');
        if (sliderEl.length) {
            sliderEl.royalSlider('updateSliderSize', true);
        }
    });

    $('.slidetabs .slidetab-links a').on('click', function(e) {
        var currentAttrValue = jQuery(this).attr('href');

        // Show/Hide Tabs
        jQuery('.slidetabs ' + currentAttrValue).show().siblings().hide();

        // Change/remove current tab to active
        jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

        jQuery(currentAttrValue + " .royalSlider").royalSlider('updateSliderSize');

        e.preventDefault();
    });

    $(".slidetabs").on("tabsactivate", function(event, ui) {
      console.log(event);
      console.log(ui);
        ui.newPanel.find('.royalSlider').data('royalSlider').updateSliderSize(true);
    });
  
  $(window).load(function() {
     // update size of slider (if you already initialized it before)
     $('.royalSlider').royalSlider('updateSliderSize', true);
});

});

jQuery(function() {
  if (window.self != window.top) {
    jQuery(document.body).addClass("in-iframe");
  }
});// JavaScript Document
