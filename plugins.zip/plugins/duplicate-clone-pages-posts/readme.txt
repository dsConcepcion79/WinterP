=== Duplicate Pages and Posts ===
Contributors: It Spiders
Donate link: http://itspiders.net/donate
Tags: clone pages, clone posts,  clone post, clone page, clone, page cloning, post cloning, posts cloning, pages cloning, page copy, page copy paste, post copy, posts copy paste, copy pages, copy posts, copy and paste posts, copy and paste pages, clone, cloning, copy and paste
Requires at least: 3.9.1
Tested up to: 4.3
Stable tag: 1.0
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Duplicating Pages and posts in WordPress.

== Description ==

This plugin that allows you clone (copy and paste) pages and pasts in one click.

= Features =
 
* Duplicating Single Page
* Duplicating Multiple Pages
* Duplicating Single post
* Duplicating Multiple posts

== Installation ==

1. Uncompress the download package
1. Upload folder including all files the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can I give other plugins you have developed? =

Please visit this link to check - http://itspiders.net

== Changelog ==

= Version 1.0 =
* 	First version

== Upgrade Notice ==
* 	First version
== Screenshots ==

1. Duplicate Single / Multiple Page


